            </div>
        </div>
    </div>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- XLSX para exportar a Excel -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    
    <!-- JavaScript -->
    <script src="../assets/js/app.js"></script>
    
    <!-- Custom JS -->
    <?php if (isset($customJS)) echo $customJS; ?>
</body>
</html>
